const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const port = 8001;

const db = require("./config/db");
const customerRoutes = require("./routes/customerRoutes");
const companyRoutes = require("./routes/companyRoutes");
const categoryRoutes = require("./routes/categoryRoutes");
const productRoutes = require("./routes/productRoutes");
const cartRoutes = require("./routes/cartRoutes");
const addressRoutes = require("./routes/addressRoutes");
const billRoutes = require("./routes/billRoutes");
const billItemRoutes = require("./routes/billItemRoutes");
const commentRoutes = require("./routes/commentRoutes");

const app = express();
app.use(express.static(path.join(__dirname, "uploads")));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());

app.use("/api/customers", customerRoutes);
app.use("/api/companies", companyRoutes);
app.use("/api/categories", categoryRoutes);
app.use("/api/products", productRoutes);
app.use("/api/bills", billRoutes);
app.use("/api/bill-items", billItemRoutes);
app.use("/api/comments", commentRoutes);
app.use("/api/cart", cartRoutes);
app.use("/api/address", addressRoutes);

app.get("/", (req, res) => {
  res.sendFile(path.resolve("./public/index.html"));
});

app.get("/create-customer", (req, res) => {
  res.sendFile(path.resolve("./public/customer_pages/create_customer.html"));
});
app.get("/read-customer", (req, res) => {
  res.sendFile(path.resolve("./public/customer_pages/read_customer.html"));
});
app.get("/update-customer", (req, res) => {
  res.sendFile(path.resolve("./public/customer_pages/update_customer.html"));
});
app.get("/delete-customer", (req, res) => {
  res.sendFile(path.resolve("./public/customer_pages/delete_customer.html"));
});

app.get("/create-company", (req, res) => {
  res.sendFile(path.resolve("./public/company_pages/create_company.html"));
});
app.get("/read-company", (req, res) => {
  res.sendFile(path.resolve("./public/company_pages/read_company.html"));
});
app.get("/update-company", (req, res) => {
  res.sendFile(path.resolve("./public/company_pages/update_company.html"));
});
app.get("/delete-company", (req, res) => {
  res.sendFile(path.resolve("./public/company_pages/delete_company.html"));
});

app.get("/create-category", (req, res) => {
  res.sendFile(path.resolve("./public/category_pages/create_category.html"));
});
app.get("/read-category", (req, res) => {
  res.sendFile(path.resolve("./public/category_pages/read_category.html"));
});
app.get("/update-category", (req, res) => {
  res.sendFile(path.resolve("./public/category_pages/update_category.html"));
});
app.get("/delete-category", (req, res) => {
  res.sendFile(path.resolve("./public/category_pages/delete_category.html"));
});

app.get("/create-product", (req, res) => {
  res.sendFile(path.resolve("./public/product_pages/create_product.html"));
});
app.get("/read-product", (req, res) => {
  res.sendFile(path.resolve("./public/product_pages/read_product.html"));
});
app.get("/update-product", (req, res) => {
  res.sendFile(path.resolve("./public/product_pages/update_product.html"));
});
app.get("/delete-product", (req, res) => {
  res.sendFile(path.resolve("./public/product_pages/delete_product.html"));
});

app.get("/create-cart-item", (req, res) => {
  res.sendFile(path.resolve("./public/cart_pages/create_cart.html"));
});
app.get("/read-cart", (req, res) => {
  res.sendFile(path.resolve("./public/cart_pages/read_cart.html"));
});
app.get("/update-cart-item", (req, res) => {
  res.sendFile(path.resolve("./public/cart_pages/update_cart.html"));
});
app.get("/delete-cart-item", (req, res) => {
  res.sendFile(path.resolve("./public/cart_pages/delete_cart.html"));
});

app.get("/create-address", (req, res) => {
  res.sendFile(path.resolve("./public/address_pages/create_address.html"));
});
app.get("/read-address", (req, res) => {
  res.sendFile(path.resolve("./public/address_pages/read_address.html"));
});
app.get("/update-address", (req, res) => {
  res.sendFile(path.resolve("./public/address_pages/update_address.html"));
});
app.get("/delete-address", (req, res) => {
  res.sendFile(path.resolve("./public/address_pages/delete_address.html"));
});

app.get("/create-bill", (req, res) => {
  res.sendFile(path.resolve("./public/bill_pages/create_bill.html"));
});
app.get("/read-bill", (req, res) => {
  res.sendFile(path.resolve("./public/bill_pages/read_bill.html"));
});
app.get("/update-bill", (req, res) => {
  res.sendFile(path.resolve("./public/bill_pages/update_bill.html"));
});
app.get("/delete-bill", (req, res) => {
  res.sendFile(path.resolve("./public/bill_pages/delete_bill.html"));
});

app.get("/create-bill-item", (req, res) => {
  res.sendFile(path.resolve("./public/bill_item_pages/create_bill_item.html"));
});
app.get("/read-bill-item", (req, res) => {
  res.sendFile(path.resolve("./public/bill_item_pages/read_bill_item.html"));
});
app.get("/update-bill-item", (req, res) => {
  res.sendFile(path.resolve("./public/bill_item_pages/update_bill_item.html"));
});
app.get("/delete-bill-item", (req, res) => {
  res.sendFile(path.resolve("./public/bill_item_pages/delete_bill_item.html"));
});

app.get("/create-comment", (req, res) => {
  res.sendFile(path.resolve("./public/comment_pages/create_comment.html"));
});
app.get("/read-comment", (req, res) => {
  res.sendFile(path.resolve("./public/comment_pages/read_comment.html"));
});
app.get("/update-comment", (req, res) => {
  res.sendFile(path.resolve("./public/comment_pages/update_comment.html"));
});
app.get("/delete-comment", (req, res) => {
  res.sendFile(path.resolve("./public/comment_pages/delete_comment.html"));
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
